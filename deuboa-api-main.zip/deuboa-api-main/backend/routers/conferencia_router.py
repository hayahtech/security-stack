from fastapi import APIRouter, UploadFile, File, Depends, HTTPException
from sqlalchemy.orm import Session
from schemas import ExtracaoResponse, ConferenciaRequest, ConferenciaResponse, ConsultaHistory
from database import get_db
import models
from services.gemini_service import extrair_dados_volante
from services.lotofacil_service import buscar_resultado_lotofacil, conferir_aposta

router = APIRouter(prefix="/api/lotofacil", tags=["lotofacil"])

@router.post("/upload", response_model=ExtracaoResponse)
async def upload_image(file: UploadFile = File(...)):
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Arquivo deve ser imagem")
        
    content = await file.read()
    resultado = extrair_dados_volante(content)
    
    return ExtracaoResponse(
        concurso=resultado.get("concurso"),
        apostas=resultado.get("apostas", [])
    )

@router.post("/conferir", response_model=ConferenciaResponse)
async def conferir_jogo(request: ConferenciaRequest, db: Session = Depends(get_db)):
    if not request.apostas:
        raise HTTPException(status_code=400, detail="Sua requisição deve conter pelo menos uma aposta.")
        
    for aposta in request.apostas:
        if len(aposta) != 15:
            raise HTTPException(status_code=400, detail="Cada aposta deve conter exatamente 15 números.")
            
    sorteados = request.numeros_sorteados_manuais
    
    # Busca API se manual não foi fornecido
    if not sorteados:
        res_api = await buscar_resultado_lotofacil(request.concurso)
        if not res_api["sucesso"]:
            raise HTTPException(status_code=404, detail="Concurso não encontrado ou API falhou. Insira os números sorteados manualmente.")
        sorteados = res_api["dezenas"]
                
    if len(sorteados) != 15:
         raise HTTPException(status_code=400, detail="Sorteio inválido. Menos de 15 números retornados.")
         
    resultados = []
    
    for aposta in request.apostas:
        conf = conferir_aposta(aposta, sorteados)
        acertos = conf["acertos"]
        
        nova = models.Consulta(
            concurso=request.concurso,
            numeros_apostados=",".join(map(str, sorted(aposta))),
            numeros_sorteados=",".join(map(str, sorted(sorteados))),
            acertos=acertos
        )
        db.add(nova)
        
        resultados.append({
            "numeros_apostados": sorted(aposta),
            "acertos": acertos,
            "faixa_premiada": conf["faixa_premiada"],
            "mensagem": conf["mensagem"],
            "valor_estimado": "Consulte a Caixa Econômica Oficial" # Simplificado, não temos os valores de rateio do bolão
        })
        
    db.commit()
    
    return ConferenciaResponse(
        concurso=request.concurso,
        numeros_sorteados=sorted(sorteados),
        resultados=resultados
    )

@router.get("/historico", response_model=list[ConsultaHistory])
def get_historico(db: Session = Depends(get_db)):
    return db.query(models.Consulta).order_by(models.Consulta.data_consulta.desc()).limit(20).all()

@router.get("/historico/resumo")
def get_historico_resumo(db: Session = Depends(get_db)):
    consultas = db.query(models.Consulta).order_by(models.Consulta.data_consulta.desc()).all()
    
    agrupado = {}
    for c in consultas:
        data_str = c.data_consulta.strftime('%Y-%m-%d')
        key = f"{c.concurso}_{data_str}"
        
        if key not in agrupado:
            agrupado[key] = {
                "data": c.data_consulta,
                "data_formatada": c.data_consulta.strftime("Dia %d/%m/%Y"),
                "concurso": c.concurso,
                "qtd_jogos": 0,
                "premio_total": 0.0
            }
            
        agrupado[key]["qtd_jogos"] += 1
        
        acertos = c.acertos
        if acertos == 11: agrupado[key]["premio_total"] += 6.0
        elif acertos == 12: agrupado[key]["premio_total"] += 12.0
        elif acertos == 13: agrupado[key]["premio_total"] += 30.0
        # Prêmios reais maiores podem ser inseridos aqui, caso disponíveis.
        elif acertos == 14: agrupado[key]["premio_total"] += 1500.0 # valor estimado
        elif acertos == 15: agrupado[key]["premio_total"] += 1000000.0 # valor estimado
        
    resultado = list(agrupado.values())
    resultado.sort(key=lambda x: x["data"], reverse=True)
    
    for r in resultado:
        r["premio_total"] = f"R$ {r['premio_total']:,.2f}".replace(',', 'X').replace('.', ',').replace('X', '.')
        
    return resultado[:15]

from services.lotofacil_sync import get_resultados
from typing import Optional

@router.get("/resultados")
def listar_resultados(page: int = 1, limit: int = 20, concurso: Optional[int] = None):
    return get_resultados(page, limit, concurso)
