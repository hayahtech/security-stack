from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class ExtracaoResponse(BaseModel):
    concurso: Optional[int]
    apostas: List[List[int]]

class ConferenciaRequest(BaseModel):
    concurso: int
    apostas: List[List[int]]
    numeros_sorteados_manuais: Optional[List[int]] = None

class ApostaResultado(BaseModel):
    numeros_apostados: List[int]
    acertos: int
    faixa_premiada: Optional[int]
    mensagem: str
    valor_estimado: str

class ResumoHistory(BaseModel):
    data_formatada: str
    concurso: int
    qtd_jogos: int
    premio_total: str

class ConferenciaResponse(BaseModel):
    concurso: int
    numeros_sorteados: List[int]
    resultados: List[ApostaResultado]

class ConsultaHistory(BaseModel):
    id: int
    concurso: int
    numeros_apostados: str
    acertos: int
    data_consulta: datetime

    class Config:
        from_attributes = True
