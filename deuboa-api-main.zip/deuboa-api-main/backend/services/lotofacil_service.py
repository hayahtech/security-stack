import httpx

async def buscar_resultado_lotofacil(concurso: int) -> dict:
    url = f"https://loteriascaixa-api.herokuapp.com/api/lotofacil/{concurso}"
    
    async with httpx.AsyncClient() as client:
        try:
            response = await client.get(url, timeout=10.0)
            if response.status_code == 200:
                data = response.json()
                dezenas = [int(d) for d in data.get("dezenas", [])]
                premiacoes = data.get("premiacoes", [])
                return {"sucesso": True, "dezenas": dezenas, "premiacoes": premiacoes}
            else:
                return {"sucesso": False, "erro": f"HTTP {response.status_code}"}
        except Exception as e:
            return {"sucesso": False, "erro": str(e)}

def conferir_aposta(apostados: list, sorteados: list):
    acertos = len(set(apostados).intersection(set(sorteados)))
    faixa = None
    mensagem = "Infelizmente não foi dessa vez. Tente novamente!"
    
    if acertos == 15:
        faixa = 15
        mensagem = "PARABÉNS! Você acertou os 15 números e ganhou o prêmio máximo!"
    elif acertos == 14:
        faixa = 14
        mensagem = "QUASE! Você acertou 14 números! Prêmio garantido."
    elif acertos in [11, 12, 13]:
        faixa = acertos
        mensagem = f"Boa! Você fez {acertos} pontos e faturou um prêmio!"
        
    return {"acertos": acertos, "faixa_premiada": faixa, "mensagem": mensagem}
