import csv
import os

_resultados_cache = []

def load_resultados_csv():
    global _resultados_cache
    if _resultados_cache:
        return _resultados_cache
        
    file_path = os.path.join(os.path.dirname(__file__), "..", "resultadosanteriores.csv")
    if not os.path.exists(file_path):
        return []
        
    resultados = []
    with open(file_path, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f, delimiter=";")
        header = next(reader, None)
        
        for row in reader:
            try:
                if len(row) < 17: continue
                concurso = int(row[0])
                data = row[1]
                
                bolas = []
                for i in range(2, 17):
                    bolas.append(int(row[i]))
                bolas.sort()
                
                resultados.append({
                    "concurso": concurso,
                    "data": data,
                    "dezenas": bolas,
                    "ganhadores_15": row[17] if len(row) > 17 else "0",
                    "rateio_15": row[18] if len(row) > 18 else "R$ 0,00",
                })
            except Exception as e:
                continue
                
    resultados.sort(key=lambda x: x["concurso"], reverse=True)
    _resultados_cache = resultados
    return _resultados_cache

def get_resultados(page: int = 1, limit: int = 20, concurso: int = None):
    todos = load_resultados_csv()
    if concurso is not None:
        todos = [r for r in todos if r["concurso"] == concurso]
        
    start = (page - 1) * limit
    end = start + limit
    return {
        "total": len(todos),
        "pagina": page,
        "limite": limit,
        "resultados": todos[start:end]
    }
