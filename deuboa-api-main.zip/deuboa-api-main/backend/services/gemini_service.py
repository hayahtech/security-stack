import os
import google.generativeai as genai
from dotenv import load_dotenv
import json
import re

load_dotenv()

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
if GEMINI_API_KEY:
    genai.configure(api_key=GEMINI_API_KEY)

model = genai.GenerativeModel('gemini-2.5-flash')

def extrair_dados_volante(image_bytes: bytes) -> dict:
    prompt = """
    Você é um assistente especializado em ler bilhetes/volantes da loteria brasileira Lotofácil.
    Este volante pode conter múltiplas apostas (Bolão) marcadas de A a J, ou apenas uma aposta.
    Extraia o número do concurso (se visível) e as 15 dezenas marcadas ou impressas para CADA aposta legível.
    Retorne APENAS um JSON estrito no formato abaixo, sem texto adicional:
    {"concurso": 1234, "apostas": [[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15], [2, 4, 6...]]}
    Se o concurso não for legível, retorne null para ele. Retorne um array vazio se não houver dezenas.
    """
    
    try:
        response = model.generate_content([
            {'mime_type': 'image/jpeg', 'data': image_bytes},
            prompt
        ])
        
        text = response.text
        print("GEMINI RAW TEXT:", text)
        text = re.sub(r'```[a-zA-Z]*\n|\n```|```', '', text).strip()
        data = json.loads(text)
        
        apostas_cruas = data.get('apostas', [])
        if not apostas_cruas and 'numeros' in data:
            if isinstance(data['numeros'], list) and len(data['numeros']) > 0:
                if isinstance(data['numeros'][0], list):
                    apostas_cruas = data['numeros']
                else:
                    apostas_cruas = [data['numeros']]

        apostas_limpas = []
        for aposta in apostas_cruas:
            try:
                if isinstance(aposta, dict):
                    lista_n = aposta.get('dezenas', aposta.get('numeros', aposta.get('dezenas_marcadas', [])))
                else:
                    lista_n = aposta
                    
                numeros = list(set([int(n) for n in lista_n if str(n).strip().isdigit() and 1 <= int(n) <= 25]))
                # Permite que apostas com menos de 15 passem, assim o usuário vê e corrige na tela
                if len(numeros) > 0:
                    apostas_limpas.append(numeros[:15])
            except Exception as e:
                print(f"Failed to parse inner aposta {aposta}: {e}")
            
        return {"concurso": data.get("concurso"), "apostas": apostas_limpas}
    except Exception as e:
        print(f"Error in Gemini OCR: {e}")
        return {"concurso": None, "apostas": []}
