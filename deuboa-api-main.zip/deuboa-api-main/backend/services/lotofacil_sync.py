import requests
from sqlalchemy.orm import Session
from models import ResultadoOficial
from database import SessionLocal
from datetime import datetime, timedelta, timezone

def fetch_and_save_next_concurso(db: Session, latest_concurso: int):
    nxt = latest_concurso + 1
    try:
        url = f"https://loteriascaixa-api.herokuapp.com/api/lotofacil/{nxt}"
        res = requests.get(url, timeout=5)
        if res.status_code == 200:
            data = res.json()
            
            p15 = next((p for p in data.get("premiacoes", []) if p["faixa"]==1), {})
            ganhadores_15 = str(p15.get("ganhadores", "0"))
            vp = p15.get("valorPremio", 0.0)
            rateio_15 = f'R$ {vp:,.2f}'.replace(',', 'X').replace('.', ',').replace('X', '.')

            novo = ResultadoOficial(
                concurso=int(data["concurso"]),
                data=data["data"],
                bola1=int(data["dezenas"][0]),
                bola2=int(data["dezenas"][1]),
                bola3=int(data["dezenas"][2]),
                bola4=int(data["dezenas"][3]),
                bola5=int(data["dezenas"][4]),
                bola6=int(data["dezenas"][5]),
                bola7=int(data["dezenas"][6]),
                bola8=int(data["dezenas"][7]),
                bola9=int(data["dezenas"][8]),
                bola10=int(data["dezenas"][9]),
                bola11=int(data["dezenas"][10]),
                bola12=int(data["dezenas"][11]),
                bola13=int(data["dezenas"][12]),
                bola14=int(data["dezenas"][13]),
                bola15=int(data["dezenas"][14]),
                ganhadores_15=ganhadores_15,
                rateio_15=rateio_15
            )
            db.add(novo)
            db.commit()
            return True
    except Exception as e:
        print(f"Erro ao sincronizar lotofacil: {e}")
    return False

def get_resultados(page: int = 1, limit: int = 20, concurso: int = None):
    db: Session = SessionLocal()
    
    latest = db.query(ResultadoOficial).order_by(ResultadoOficial.concurso.desc()).first()
    if latest:
        agora_br = datetime.now(timezone(timedelta(hours=-3)))
        hoje_br = agora_br.date()
        try:
            data_ultimo = datetime.strptime(latest.data, "%d/%m/%Y").date()
            dias_diff = (hoje_br - data_ultimo).days
            
            # Se atrasou 2 dias ou mais, puxa. Se for o dia seguinte do sorteio, só puxa depois das 23h.
            if dias_diff >= 2 or (dias_diff == 1 and agora_br.hour >= 23):
                fetch_and_save_next_concurso(db, latest.concurso)
        except:
            pass

    query = db.query(ResultadoOficial)
    if concurso:
        query = query.filter(ResultadoOficial.concurso == concurso)
        
    total = query.count()
    resultados = query.order_by(ResultadoOficial.concurso.desc()).offset((page - 1) * limit).limit(limit).all()
    
    lista = []
    for r in resultados:
        lista.append({
            "concurso": r.concurso,
            "data": r.data,
            "dezenas": sorted([r.bola1, r.bola2, r.bola3, r.bola4, r.bola5, r.bola6, r.bola7, r.bola8, r.bola9, r.bola10, r.bola11, r.bola12, r.bola13, r.bola14, r.bola15]),
            "ganhadores_15": r.ganhadores_15,
            "rateio_15": r.rateio_15
        })
        
    db.close()
    
    return {
        "total": total,
        "pagina": page,
        "limite": limit,
        "resultados": lista
    }
