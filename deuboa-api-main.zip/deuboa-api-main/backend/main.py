from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from database import engine, Base
from routers import conferencia_router

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Kal Lotofácil API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(conferencia_router.router)

@app.get("/")
def root():
    return {"message": "API Kal Lotofácil funcionando!"}
