import csv
import os
from database import engine, Base, SessionLocal
from models import ResultadoOficial

def seed_database():
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    
    if db.query(ResultadoOficial).first():
        print("Banco de dados já contém resultados. Parando...")
        db.close()
        return

    csv_path = os.path.join(os.path.dirname(__file__), "resultadosanteriores.csv")
    if not os.path.exists(csv_path):
        print(f"Arquivo {csv_path} não encontrado.")
        db.close()
        return

    with open(csv_path, "r", encoding="utf-8-sig") as f:
        reader = csv.reader(f, delimiter=";")
        next(reader, None)
        
        batch = []
        for row in reader:
            try:
                if len(row) < 17: continue
                batch.append(ResultadoOficial(
                    concurso=int(row[0]),
                    data=row[1],
                    bola1=int(row[2]),
                    bola2=int(row[3]),
                    bola3=int(row[4]),
                    bola4=int(row[5]),
                    bola5=int(row[6]),
                    bola6=int(row[7]),
                    bola7=int(row[8]),
                    bola8=int(row[9]),
                    bola9=int(row[10]),
                    bola10=int(row[11]),
                    bola11=int(row[12]),
                    bola12=int(row[13]),
                    bola13=int(row[14]),
                    bola14=int(row[15]),
                    bola15=int(row[16]),
                    ganhadores_15=row[17] if len(row) > 17 else "0",
                    rateio_15=row[18] if len(row) > 18 else "R$ 0,00"
                ))
            except Exception as e:
                continue
                
        if batch:
            db.add_all(batch)
            db.commit()
            print(f"Subidos {len(batch)} concursos antigos do CSV para o Supabase!")

    db.close()

if __name__ == "__main__":
    seed_database()
