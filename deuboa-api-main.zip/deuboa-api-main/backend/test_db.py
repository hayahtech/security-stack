import sqlalchemy
from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base

url = "postgresql://postgres.qgaejipzdqtjmergwojx:%40MoDelo47%24mP2@aws-1-sa-east-1.pooler.supabase.com:6543/postgres"
engine = create_engine(url)

try:
    with engine.connect() as conn:
        print("CONEXAO BEM SUCEDIDA COM A NOVA URI!")
except Exception as e:
    print("FALHA!")
    print(e)
