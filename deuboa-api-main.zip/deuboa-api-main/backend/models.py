from sqlalchemy import Column, Integer, String, Float, DateTime
from database import Base
import datetime

class Consulta(Base):
    __tablename__ = "consultas"

    id = Column(Integer, primary_key=True, index=True)
    concurso = Column(Integer)
    numeros_apostados = Column(String) # Ex: "01,02,03..."
    numeros_sorteados = Column(String) # Ex: "01,02,03..."
    acertos = Column(Integer)
    premio = Column(Float, default=0.0)
    data_consulta = Column(DateTime, default=datetime.datetime.utcnow)

class ResultadoOficial(Base):
    __tablename__ = "resultado_oficial"
    concurso = Column(Integer, primary_key=True, index=True)
    data = Column(String)
    bola1 = Column(Integer)
    bola2 = Column(Integer)
    bola3 = Column(Integer)
    bola4 = Column(Integer)
    bola5 = Column(Integer)
    bola6 = Column(Integer)
    bola7 = Column(Integer)
    bola8 = Column(Integer)
    bola9 = Column(Integer)
    bola10 = Column(Integer)
    bola11 = Column(Integer)
    bola12 = Column(Integer)
    bola13 = Column(Integer)
    bola14 = Column(Integer)
    bola15 = Column(Integer)
    ganhadores_15 = Column(String)
    rateio_15 = Column(String)
