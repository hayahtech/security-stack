import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { History } from 'lucide-react';
import Home from './pages/Home';
import Confirmacao from './pages/Confirmacao';
import Resultado from './pages/Resultado';
import Historico from './pages/Historico';
import ResultadosGerais from './pages/ResultadosGerais';

function App() {
  return (
    <BrowserRouter>
      <main className="min-h-screen bg-background text-textMain pb-10">
        <header className="p-4 border-b border-gray-200 bg-surface mb-6 sticky top-0 z-50 shadow-md">
          <div className="container mx-auto max-w-md flex justify-between items-center">
            <Link to="/">
              <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-teal-400 bg-clip-text text-transparent flex items-center gap-2">
                <span className="text-2xl">🍀</span> Kal Lotofácil
              </h1>
            </Link>
            <Link to="/historico" className="text-textMuted hover:text-gray-800 transition-colors bg-gray-100 p-2 rounded-full">
              <History size={20} />
            </Link>
          </div>
        </header>
        
        <div className="container mx-auto max-w-md px-4">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/confirmacao" element={<Confirmacao />} />
            <Route path="/resultado" element={<Resultado />} />
            <Route path="/historico" element={<Historico />} />
            <Route path="/resultados-gerais" element={<ResultadosGerais />} />
          </Routes>
        </div>
      </main>
      <Toaster position="bottom-center" toastOptions={{
        style: {
          background: '#262730',
          color: '#fff',
          border: '1px solid rgba(255,255,255,0.1)'
        }
      }} />
    </BrowserRouter>
  );
}

export default App;
