import { useLocation, useNavigate } from 'react-router-dom';
import { Trophy, ArrowLeft, RefreshCw, AlertCircle } from 'lucide-react';

export default function Resultado() {
  const location = useLocation();
  const navigate = useNavigate();
  const res = location.state?.resultado;

  if (!res) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] space-y-4 fade-in">
        <AlertCircle size={48} className="text-danger" />
        <p className="text-textMuted text-center px-6">Nenhum resultado encontrado na sessão. Retorne ao início para conferir.</p>
        <button onClick={() => navigate('/')} className="btn-primary mt-4">Início</button>
      </div>
    );
  }

  const { concurso, numeros_sorteados, resultados } = res;
  
  const totalPremio = resultados.reduce((acc: number, r: any) => acc + (r.acertos >= 11 ? 1 : 0), 0);
  const maxAcertos = Math.max(...resultados.map((r: any) => r.acertos));
  const isWinnerGlobal = maxAcertos >= 11;

  return (
    <div className="space-y-6 pb-8 animate-in slide-in-from-bottom-5 duration-500">
      <div className="text-center space-y-2 pt-2">
        <div className={`mx-auto w-20 h-20 rounded-full flex items-center justify-center shadow-2xl mb-4 transition-all
            ${isWinnerGlobal ? 'bg-primary text-gray-800 shadow-primary/40' : 'bg-surface text-textMuted border border-gray-200'}
        `}>
          <Trophy size={40} className={isWinnerGlobal ? "animate-bounce" : ""} />
        </div>
        <h2 className="text-4xl font-extrabold bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent">
          {isWinnerGlobal ? `${totalPremio} Aposta(s) Premiada(s)!` : 'Não foi dessa vez'}
        </h2>
        <p className={`font-semibold text-lg ${isWinnerGlobal ? 'text-primary' : 'text-danger'}`}>
          Melhor placar: {maxAcertos} acertos
        </p>
      </div>

      <div className="flex justify-between items-center border-b border-gray-200 pb-4 mt-8">
        <span className="text-textMuted text-sm font-medium">Concurso {concurso}</span>
        <span className="text-gray-800 text-xs bg-gray-100 px-3 py-1 rounded-full border border-gray-200 font-semibold">
          {resultados.length} Aposta{resultados.length > 1 ? 's' : ''}
        </span>
      </div>

      <div className="space-y-6">
        {resultados.map((aposta: any, index: number) => {
          const { acertos, mensagem, numeros_apostados } = aposta;
          const isWinner = acertos >= 11;
          
          return (
            <div key={index} className="card relative overflow-hidden">
               {isWinner && <div className="absolute -top-10 -right-10 w-40 h-40 bg-primary/20 blur-3xl rounded-full pointer-events-none" />}
               
               <div className="flex justify-between items-center mb-3">
                  <h3 className="text-sm font-bold text-gray-800">Aposta {String.fromCharCode(65 + index)}</h3>
                  <span className={`text-xs font-bold px-2 py-1 rounded-full ${isWinner ? 'bg-primary/20 text-primary' : 'bg-danger/10 text-danger'}`}>
                    {acertos} Acertos
                  </span>
               </div>
               
               <p className={`text-xs font-medium mb-4 ${isWinner ? 'text-yellow-500' : 'text-textMuted'}`}>
                 {mensagem}
               </p>
               
               <div className="grid grid-cols-5 gap-2 mt-2">
                 {Array.from({ length: 25 }, (_, i) => i + 1).map((num) => {
                   const isApostado = numeros_apostados.includes(num);
                   const isSorteado = numeros_sorteados.includes(num);
                   
                   let bgColor = "bg-gray-100 text-gray-600 border border-gray-200 opacity-40"; 
                   if (isApostado && isSorteado) bgColor = "bg-primary text-white shadow-md shadow-primary/30 scale-105 z-10 font-bold border-2 border-primary";
                   else if (isApostado && !isSorteado) bgColor = "bg-danger/10 text-danger border border-danger/30 font-medium";
                   else if (!isApostado && isSorteado) bgColor = "bg-surface text-primary border border-primary/40 opacity-80 font-medium";

                   return (
                     <div key={num} className={`aspect-square rounded-xl flex items-center justify-center text-sm transition-all ${bgColor}`}>
                       {num.toString().padStart(2, '0')}
                     </div>
                   );
                 })}
               </div>
            </div>
          );
        })}
      </div>

      <div className="flex flex-wrap justify-center gap-4 mt-6 text-xs bg-gray-100 p-4 rounded-xl border border-gray-200">
        <div className="flex items-center gap-2"><div className="w-4 h-4 bg-primary rounded shadow shadow-primary/30"></div><span className="text-gray-700 font-medium">Acerto</span></div>
        <div className="flex items-center gap-2"><div className="w-4 h-4 bg-danger/20 border border-danger/30 rounded"></div><span className="text-gray-700">Erro</span></div>
        <div className="flex items-center gap-2"><div className="w-4 h-4 bg-surface border border-primary/40 rounded"></div><span className="text-gray-700">Sorteado (Não marcado)</span></div>
      </div>

      <div className="flex gap-3 pt-6">
        <button onClick={() => navigate('/')} className="flex-1 btn-primary bg-surface hover:bg-gray-200 text-gray-800 shadow-none border border-gray-200 flex items-center justify-center gap-2 h-14">
          <ArrowLeft size={20}/> Início
        </button>
        <button 
          onClick={() => navigate('/confirmacao', { state: { extracao: { concurso, apostas: resultados.map((r:any) => r.numeros_apostados) } } })} 
          className="flex-[2] btn-primary flex items-center justify-center gap-2 h-14"
        >
          <RefreshCw size={20}/> Conferir Novamente
        </button>
      </div>
    </div>
  );
}
