import { useState, useRef, useEffect } from 'react';
import { Upload, Loader2, ListOrdered, History, Trophy } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../services/api';

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [resumo, setResumo] = useState<any[]>([]);
  const [loadingResumo, setLoadingResumo] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchResumo() {
      try {
        const response = await api.get('/historico/resumo');
        setResumo(response.data);
      } catch (error) {
        console.error("Erro ao carregar resumo histórico", error);
      } finally {
        setLoadingResumo(false);
      }
    }
    fetchResumo();
  }, []);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('file', file);

    setLoading(true);
    const toastId = toast.loading('Analisando imagem com IA...');
    
    try {
      const response = await api.post('/upload', formData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });
      
      toast.success('Dezenas extraídas!', { id: toastId });
      navigate('/confirmacao', { state: { extracao: response.data } });
    } catch (error) {
      toast.error('Erro ao ler a imagem. Tente novamente ou digite manualmente.', { id: toastId });
      console.error(error);
    } finally {
      setLoading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="flex flex-col items-center justify-center space-y-6 pt-2 pb-10 fade-in">
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-extrabold text-primary drop-shadow-sm tracking-tight">Deu boa!</h2>
        <p className="text-textMuted text-sm px-4">Não perca tempo - Confira seus jogos da Lotofácil de maneira mais rápida e fácil.</p>
      </div>

      <div className="card w-full flex flex-col items-center space-y-6">
        <div className="bg-white w-24 h-24 rounded-full border border-gray-200 shadow-md flex items-center justify-center overflow-hidden">
          <img src="/camera-icon.png" alt="Câmera" className="w-full h-full object-cover scale-[1.35] hover:scale-[1.45] transition-transform cursor-pointer" onClick={() => fileInputRef.current?.click()} />
        </div>

        <button 
          onClick={() => fileInputRef.current?.click()}
          disabled={loading}
          className="btn-primary w-full flex items-center justify-center gap-2 text-lg h-14"
        >
          {loading ? (
            <><Loader2 className="animate-spin" /> Analisando Volante...</>
          ) : (
            <><Upload size={24} /> Enviar Comprovante</>
          )}
        </button>

        <input 
          type="file" 
          accept="image/*" 
          capture="environment"
          className="hidden" 
          ref={fileInputRef}
          onChange={handleFileChange}
        />
        
        <p className="text-xs text-textMuted max-w-[250px] text-center">
          Formatos suportados: JPG, PNG, WEBP.
        </p>
      </div>

      <button 
         onClick={() => navigate('/confirmacao', { state: { extracao: { concurso: null, apostas: [] } } })}
         className="text-primary hover:text-gray-800 transition-colors text-sm underline flex items-center gap-1 mt-2"
      >
        <ListOrdered size={16} /> Digitar aposta manualmente
      </button>

      <div className="w-full flex gap-3 pt-4">
          <button onClick={() => navigate('/historico')} className="flex-1 bg-surface border border-gray-200 p-4 rounded-xl flex flex-col items-center justify-center gap-2 hover:bg-gray-100 transition-colors shadow-lg">
             <History size={24} className="text-primary" />
             <span className="text-xs font-semibold text-center mt-1">Histórico de Apostas</span>
          </button>
          
          <button onClick={() => navigate('/resultados-gerais')} className="flex-1 bg-surface border border-gray-200 p-4 rounded-xl flex flex-col items-center justify-center gap-2 hover:bg-gray-100 transition-colors shadow-lg">
             <Trophy size={24} className="text-primary" />
             <span className="text-xs font-semibold text-center mt-1">Resultados da Lotofácil</span>
          </button>
      </div>

      <div className="w-full space-y-3 pt-4 border-t border-gray-200">
          <h3 className="text-sm font-semibold text-gray-800/90 flex items-center gap-2">Últimas Conferências</h3>
          {loadingResumo ? (
             <div className="flex justify-center p-4"><Loader2 className="animate-spin text-primary" /></div>
          ) : resumo.length === 0 ? (
             <p className="text-xs text-textMuted text-center p-4 bg-surface rounded-xl border border-gray-200">Você ainda não conferiu nenhuma aposta.</p>
          ) : (
             <div className="space-y-2">
               {resumo.map((item, i) => (
                 <div key={i} className="bg-surface border border-gray-200 p-3 px-4 rounded-xl flex items-center justify-between shadow-sm hover:border-gray-200 transition-colors">
                    <p className="text-xs text-gray-700 font-medium">
                        {item.data_formatada} - Concurso {item.concurso} - {item.qtd_jogos} jogos - <span className="text-yellow-500 font-bold">Prêmio {item.premio_total}</span>
                    </p>
                 </div>
               ))}
             </div>
          )}
      </div>
    </div>
  );
}
