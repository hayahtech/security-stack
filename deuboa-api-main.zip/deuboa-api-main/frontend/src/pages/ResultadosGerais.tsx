import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Trophy, Loader2, Search } from 'lucide-react';
import api from '../services/api';

export default function ResultadosGerais() {
  const navigate = useNavigate();
  const [resultados, setResultados] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [busca, setBusca] = useState('');

  const fetchResultados = async (pageNum: number, textBusca: string = '') => {
    try {
      const url = textBusca.trim() ? `/resultados?page=${pageNum}&limit=10&concurso=${textBusca.trim()}` : `/resultados?page=${pageNum}&limit=10`;
      const response = await api.get(url);
      if (response.data.resultados.length < 10) {
        setHasMore(false);
      } else {
        setHasMore(true);
      }
      if (pageNum === 1) {
        setResultados(response.data.resultados);
      } else {
        setResultados(prev => [...prev, ...response.data.resultados]);
      }
    } catch (error) {
      console.error('Erro ao buscar resultados', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchResultados(1, busca);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    setLoading(true);
    fetchResultados(1, busca);
  };

  const loadMore = () => {
    const nextPage = page + 1;
    setPage(nextPage);
    fetchResultados(nextPage, busca);
  };

  return (
    <div className="space-y-6 pb-8 animate-in slide-in-from-bottom-5 duration-500">
      <div className="flex items-center gap-3 mb-6 mt-2 sticky top-[88px] bg-background/90 backdrop-blur-md z-40 py-3 shadow-sm px-1 border-b border-gray-200">
        <button onClick={() => navigate('/')} className="p-2 bg-surface rounded-full text-gray-800 hover:bg-gray-200 transition-colors border border-gray-200">
          <ArrowLeft size={20} />
        </button>
        <h2 className="text-xl font-semibold flex items-center gap-2 text-gray-800">
           <Trophy className="text-primary" /> Resultados Oficiais
        </h2>
      </div>

      <div className="space-y-4 px-2">
        <form onSubmit={handleSearch} className="relative pb-2">
           <input 
             type="number" 
             placeholder="Buscar nº do concurso..." 
             className="w-full bg-surface border border-gray-200 rounded-xl py-3 pl-11 pr-4 text-gray-800 focus:outline-none focus:border-primary shadow-sm"
             value={busca}
             onChange={(e) => setBusca(e.target.value)}
           />
           <Search className="absolute left-3 top-3.5 text-gray-400" size={20} />
           <button type="submit" className="hidden">Buscar</button>
        </form>

        {resultados.map((r, idx) => (
          <div key={r.concurso || idx} className="card p-4 space-y-3 shadow-lg hover:border-gray-200 transition-colors bg-surface border border-gray-200 relative overflow-hidden">
            
            <div className="flex justify-between items-center border-b border-gray-200 pb-2">
               <span className="text-sm font-bold bg-primary/20 text-primary px-3 py-1 rounded-full">
                 Concurso {r.concurso}
               </span>
               <span className="text-xs font-semibold text-textMuted bg-gray-100 px-2 py-1 rounded">
                 {r.data}
               </span>
            </div>
            
            <div className="grid grid-cols-5 gap-y-3 gap-x-2 py-3 justify-items-center bg-gray-100/50 rounded-xl px-1">
               {r.dezenas.map((d: number) => (
                 <div key={d} className="w-8 h-8 rounded-full bg-primary text-white shadow-md shadow-primary/20 font-bold flex items-center justify-center text-xs">
                   {String(d).padStart(2, '0')}
                 </div>
               ))}
            </div>

            <div className="flex justify-between items-center bg-gray-100 p-3 rounded-lg border border-gray-200 mt-2">
               <span className="text-xs font-semibold text-gray-700">15 Acertos</span>
               <div className="text-right">
                  <span className="text-[13px] font-bold text-yellow-500">{r.rateio_15}</span>
                  <span className="text-[10px] text-textMuted block opacity-80 mt-0.5">{r.ganhadores_15} ganhador(es)</span>
               </div>
            </div>
          </div>
        ))}
        
        {loading && <div className="flex justify-center py-6"><Loader2 className="animate-spin text-primary" size={32} /></div>}
        
        {!loading && hasMore && (
           <button onClick={loadMore} className="w-full py-4 bg-surface border border-gray-200 rounded-xl text-sm font-semibold text-primary hover:bg-gray-100 transition-colors shadow-md mt-4">
             Carregar mais resultados
           </button>
        )}
      </div>
    </div>
  );
}
