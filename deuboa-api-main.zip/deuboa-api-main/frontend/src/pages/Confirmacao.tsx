import { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Check, Edit2, Loader2, ChevronLeft, Plus, Trash2 } from 'lucide-react';
import toast from 'react-hot-toast';
import api from '../services/api';

export default function Confirmacao() {
  const location = useLocation();
  const navigate = useNavigate();
  const [concurso, setConcurso] = useState('');
  const [apostas, setApostas] = useState<number[][]>([[]]);
  const [activeTab, setActiveTab] = useState(0);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!location.state) return;
    
    const extracao = location.state?.extracao;
    setConcurso(extracao?.concurso ? String(extracao.concurso) : '');
    if (extracao?.apostas && extracao.apostas.length > 0) {
      setApostas(extracao.apostas);
    } else {
      setApostas([[]]);
    }
  }, [location.state, navigate]);

  const numeros = apostas[activeTab] || [];

  const toggleNumero = (num: number) => {
    const newApostas = [...apostas];
    const current = newApostas[activeTab] || [];
    
    if (current.includes(num)) {
      newApostas[activeTab] = current.filter(n => n !== num);
      setApostas(newApostas);
    } else {
      if (current.length < 15) {
        newApostas[activeTab] = [...current, num].sort((a,b) => a - b);
        setApostas(newApostas);
      } else {
        toast.error('Você já selecionou 15 números nesta aposta.');
      }
    }
  };

  const addAposta = () => {
    setApostas([...apostas, []]);
    setActiveTab(apostas.length);
  };

  const removeAposta = (index: number) => {
    if (apostas.length <= 1) {
      toast.error('Você precisa ter pelo menos uma aposta.');
      return;
    }
    const newApostas = apostas.filter((_, i) => i !== index);
    setApostas(newApostas);
    if (activeTab >= newApostas.length) {
      setActiveTab(newApostas.length - 1);
    }
  };

  const handleConferir = async () => {
    for (let i = 0; i < apostas.length; i++) {
        if (apostas[i].length !== 15) {
            setActiveTab(i);
            toast.error(`A Aposta ${i + 1} não tem 15 números (tem ${apostas[i].length}). Corrija-a.`);
            return;
        }
    }

    if (!concurso.trim()) {
      toast.error('Informe o número do concurso.');
      return;
    }

    setLoading(true);
    const toastId = toast.loading('Calculando resultados...');

    try {
      const response = await api.post('/conferir', {
        concurso: parseInt(concurso, 10),
        apostas: apostas,
      });
      
      toast.success('Conferência finalizada!', { id: toastId });
      navigate('/resultado', { state: { resultado: response.data } });
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Erro ao conferir. A API pode estar indisponível.', { id: toastId });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3 mb-2">
        <button onClick={() => navigate('/')} className="p-2 bg-surface rounded-full text-gray-800 hover:bg-gray-200 transition-colors">
          <ChevronLeft size={20} />
        </button>
        <h2 className="text-xl font-semibold">Suas Apostas</h2>
      </div>

      <div className="card space-y-4">
        <div>
          <label className="block text-sm text-textMuted mb-2">Concurso (Sorteio)</label>
          <input 
            type="number" 
            value={concurso}
            onChange={(e) => setConcurso(e.target.value)}
            placeholder="Ex: 3050"
            className="w-full bg-gray-100 border border-gray-200 rounded-xl p-3 text-gray-800 focus:outline-none focus:border-primary transition-colors h-14"
          />
        </div>

        {/* Tabs for Multiple Bets */}
        <div className="pt-2">
           <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {apostas.map((_, i) => (
                  <button 
                    key={i} 
                    onClick={() => setActiveTab(i)}
                    className={`whitespace-nowrap px-4 py-2 rounded-full text-sm font-medium transition-colors border ${activeTab === i ? 'bg-primary border-primary text-white shadow-md' : 'bg-white border-gray-200 text-gray-500'}`}
                  >
                     Aposta {String.fromCharCode(65 + i)}
                  </button>
              ))}
              <button 
                  onClick={addAposta}
                  className="px-4 py-2 rounded-full text-sm font-medium border border-dashed border-gray-300 text-gray-800/50 hover:text-gray-800"
              >
                 <Plus size={18} />
              </button>
           </div>
        </div>

        <div className="pt-2 bg-gray-100 p-4 rounded-xl border border-gray-200">
          <div className="flex justify-between items-center mb-4">
            <label className="text-sm text-gray-800 font-medium">Dezenas ({numeros.length}/15)</label>
            <div className="flex gap-3">
                <span className="text-xs text-primary flex items-center gap-1 opacity-80"><Edit2 size={12}/> Edite livremente</span>
                {apostas.length > 1 && (
                    <button onClick={() => removeAposta(activeTab)} className="text-danger flex items-center gap-1 text-xs opacity-80 hover:opacity-100">
                        <Trash2 size={12} /> Remover
                    </button>
                )}
            </div>
          </div>
          
          <div className="grid grid-cols-5 gap-2">
            {Array.from({ length: 25 }, (_, i) => i + 1).map((num) => {
              const selected = numeros.includes(num);
              return (
                <button
                  key={num}
                  onClick={() => toggleNumero(num)}
                  className={`aspect-square rounded-xl flex items-center justify-center font-semibold text-sm transition-all
                    ${selected 
                      ? 'bg-primary text-white shadow-md shadow-primary/30 scale-105 border-transparent' 
                      : 'bg-surface text-textMuted border border-gray-200 hover:border-gray-300'}`}
                >
                  {num.toString().padStart(2, '0')}
                </button>
              );
            })}
          </div>
        </div>

        <button 
          onClick={handleConferir} 
          disabled={loading || !concurso.trim()}
          className="btn-primary w-full flex items-center justify-center gap-3 h-14 mt-6"
        >
          {loading ? <Loader2 className="animate-spin" /> : <Check />}
          Conferir {apostas.length} Aposta{apostas.length > 1 ? 's' : ''}
        </button>
      </div>
    </div>
  );
}
