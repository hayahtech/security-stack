import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, History as HistoryIcon, Loader2 } from 'lucide-react';
import api from '../services/api';

export default function Historico() {
  const navigate = useNavigate();
  const [historico, setHistorico] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadHistorico() {
      try {
        const response = await api.get('/historico');
        setHistorico(response.data);
      } catch (error) {
        console.error("Erro ao carregar histórico: ", error);
      } finally {
        setLoading(false);
      }
    }
    loadHistorico();
  }, []);

  return (
    <div className="space-y-6 pb-8 animate-in slide-in-from-bottom-5 duration-500">
      <div className="flex items-center gap-3 mb-6 mt-2">
        <button onClick={() => navigate('/')} className="p-2 bg-surface rounded-full text-gray-800 hover:bg-gray-200 transition-colors">
          <ArrowLeft size={20} />
        </button>
        <h2 className="text-xl font-semibold flex items-center gap-2">
           <HistoryIcon className="text-primary" /> Histórico de Apostas
        </h2>
      </div>

      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="animate-spin text-primary" size={32} /></div>
      ) : historico.length === 0 ? (
        <div className="text-center py-10 text-textMuted flex flex-col items-center">
            <Clock size={48} className="mb-4 opacity-50" />
            <p>Nenhuma aposta registrada ainda.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {historico.map((item, idx) => {
            const date = new Date(item.data_consulta).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
            const isWinner = item.acertos >= 11;
            
            return (
              <div key={item.id || idx} className="card p-4 relative overflow-hidden flex flex-col gap-3">
                 <div className="flex justify-between items-center border-b border-gray-200 pb-2">
                    <span className="text-xs text-textMuted">{date}</span>
                    <span className="text-xs font-semibold bg-gray-100 px-2 py-1 rounded border border-gray-200">
                      Concurso {item.concurso}
                    </span>
                 </div>
                 
                 <div className="flex justify-between items-center mt-1">
                    <div className="text-sm font-medium text-gray-700">
                       <span className="text-xs text-textMuted block mb-1">Dezenas</span>
                       <p className="tracking-widest">{item.numeros_apostados.split(',').map((n: string) => n.padStart(2, '0')).join(' ')}</p>
                    </div>
                 </div>

                 <div className="mt-2 flex">
                    <span className={`text-xs font-bold px-3 py-1.5 rounded-full flex items-center gap-1 ${isWinner ? 'bg-primary/20 text-primary' : 'bg-surface text-textMuted border border-gray-200'}`}>
                      {item.acertos} Acertos
                    </span>
                 </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
