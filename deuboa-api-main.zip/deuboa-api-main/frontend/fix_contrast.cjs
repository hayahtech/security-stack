const fs = require('fs');

const file = 'c:/Users/User/Documents/códigos/kal-lotofacil/frontend/src/pages/Confirmacao.tsx';
let txt = fs.readFileSync(file, 'utf8');
txt = txt.replace('bg-primary border-primary text-gray-800', 'bg-primary border-primary text-white shadow-md');
txt = txt.replace('bg-primary text-gray-800 shadow-lg', 'bg-primary text-white shadow-md');
fs.writeFileSync(file, txt, 'utf8');

const file2 = 'c:/Users/User/Documents/códigos/kal-lotofacil/frontend/src/pages/Resultado.tsx';
let txt2 = fs.readFileSync(file2, 'utf8');
txt2 = txt2.replace('bg-primary text-gray-800 shadow-lg', 'bg-primary text-white shadow-md');
fs.writeFileSync(file2, txt2, 'utf8');

const file3 = 'c:/Users/User/Documents/códigos/kal-lotofacil/frontend/src/pages/ResultadosGerais.tsx';
let txt3 = fs.readFileSync(file3, 'utf8');
txt3 = txt3.replace('text-gray-800 bg-primary/20', 'bg-primary/20');
txt3 = txt3.replace('flex flex-wrap gap-2 py-2 justify-center', 'grid grid-cols-5 gap-y-3 gap-x-2 py-3 justify-items-center');
txt3 = txt3.replace('bg-primary text-gray-800 shadow-lg', 'bg-primary text-white shadow-md');
fs.writeFileSync(file3, txt3, 'utf8');

console.log("Fixes applied.");
