const fs = require('fs');
const path = require('path');

const tsxFiles = [
    'App.tsx',
    'pages/Home.tsx',
    'pages/Confirmacao.tsx',
    'pages/Resultado.tsx',
    'pages/Historico.tsx',
    'pages/ResultadosGerais.tsx'
];

tsxFiles.forEach(file => {
    const filePath = path.join(__dirname, 'src', file);
    if (!fs.existsSync(filePath)) return;
    
    let content = fs.readFileSync(filePath, 'utf8');
    
    content = content.replace(/bg-\[\#1D1E24\]/g, 'bg-gray-100')
                     .replace(/border-white\/5/g, 'border-gray-200')
                     .replace(/border-white\/10/g, 'border-gray-200')
                     .replace(/border-white\/20/g, 'border-gray-300')
                     .replace(/text-white/g, 'text-gray-800')
                     .replace(/text-white\/90/g, 'text-gray-800')
                     .replace(/text-gray-300/g, 'text-gray-700')
                     .replace(/bg-white\/5/g, 'bg-gray-100')
                     .replace(/bg-white\/10/g, 'bg-gray-200')
                     .replace(/hover:bg-white\/10/g, 'hover:bg-gray-200')
                     .replace(/hover:bg-white\/5/g, 'hover:bg-gray-100')
                     .replace(/hover:border-white\/10/g, 'hover:border-gray-300')
                     .replace(/bg-surface border-gray-200 text-textMuted/g, 'bg-white border-gray-200 text-gray-500');
                     
    fs.writeFileSync(filePath, content, 'utf8');
});

console.log("Light mode fixes complete");
