# Kal Lotofácil

Aplicativo inteligente para conferência automatizada de volantes da Lotofácil usando Inteligência Artificial (Google Gemini Vision) para extrair os números apostados a partir de fotos do comprovante.

## Tecnologias Utilizadas
- **Backend**: Python, FastAPI, SQLite, SQLAlchemy, Google Gemini API.
- **Frontend**: React 18, Vite, TypeScript, Tailwind CSS, Lucide React, Axios.

## Como Executar (Docker Compose) - Recomendado

1. Na raiz do projeto (`kal-lotofacil`), execute:
```bash
docker-compose up --build
```
2. Acesse a aplicação em `http://localhost:5173`
3. A API Backend estará em `http://localhost:8000/docs`

## Como Executar Manualmente (Local)

### 1. Backend
```bash
cd backend
python -m venv .venv
# Ative o ambiente virtual
# Windows: .venv\Scripts\activate
# Linux/Mac: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

### 2. Frontend
Abra um novo terminal:
```bash
cd frontend
npm install
npm run dev
```
Acesse no seu navegador ou celular na mesma rede local.

---
Desenvolvido via pair-programming com Antigravity Agent.
