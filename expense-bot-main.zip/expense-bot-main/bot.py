import os
import logging
from datetime import datetime, timedelta
from decimal import Decimal
import re
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ConversationHandler,
    ContextTypes,
    filters,
)
from supabase import create_client, Client
import asyncio

# Configuração de logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Configurações
TELEGRAM_TOKEN = "8366738689:AAFP3meMpGa59F0e4Gb_k5mPnAbYZ3nHoL4"
SUPABASE_URL = "https://irapvleriikdqwltstzj.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlyYXB2bGVyaWlrZHF3bHRzdHpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjQ4Njg0ODEsImV4cCI6MjA4MDQ0NDQ4MX0.xhwns-LKyTuvHFBOi8Ut6DEIlBCoo-KmMRW2CQ5n56Q"

# Inicializar Supabase
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# Estados da conversa
AMOUNT, CATEGORY, PAYMENT_METHOD, DESCRIPTION = range(4)

# Categorias disponíveis
CATEGORIES = [
    "Alimentação", "Restaurantes e delivery", "Combustível", "Pedágio",
    "Doações", "Saúde", "Streaming", "Telefonia", "Energia elétrica",
    "Gás", "Água", "Condomínio", "Financiamento Casa", "Crédito Carro",
    "Seguro veículo", "Revisão", "Ipva e licenciamento", "Multas",
    "Móveis", "Imóveis", "Ingressos", "i.a", "api", "Passagens",
    "Materiais pra escritório"
]

# Métodos de pagamento
PAYMENT_METHODS = [
    "Dinheiro", "Cartão 1 mbg", "Cartão 2 mbg", "Cartão 3 mbg",
    "Cartão 4 mbg", "Cartão 5 mbg", "Cartão 1 rad", "Cartão 2 rad",
    "Cartão 3 rad", "Cartão 4 rad", "Cartão 5 rad", "Cartão 6 rad",
    "Cartão 7 rad", "Cartão 8 rad", "Cartão 9 rad"
]

# Função auxiliar para criar teclado
def create_keyboard(options, columns=2):
    keyboard = []
    for i in range(0, len(options), columns):
        keyboard.append(options[i:i+columns])
    return ReplyKeyboardMarkup(keyboard, one_time_keyboard=True, resize_keyboard=True)

# Comando /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    logger.info("========= COMANDO /start RECEBIDO =========")
    user = update.effective_user
    logger.info(f"Usuário: {user.id} - {user.first_name} - @{user.username}")
    
    # Registrar usuário no banco
    try:
        logger.info("Tentando registrar usuário no Supabase...")
        supabase.table('users').upsert({
            'telegram_id': user.id,
            'username': user.username,
            'first_name': user.first_name
        }).execute()
        logger.info("Usuário registrado com sucesso!")
    except Exception as e:
        logger.error(f"Erro ao registrar usuário: {e}")
    
    try:
        logger.info("Enviando mensagem de boas-vindas...")
        await update.message.reply_text(
            f"👋 Olá {user.first_name}!\n\n"
            "Bem-vindo ao seu assistente de controle de gastos!\n\n"
            "📝 *Comandos disponíveis:*\n"
            "/add - Adicionar novo gasto\n"
            "/relatorio_semanal - Relatório da semana\n"
            "/relatorio_mensal - Relatório do mês\n"
            "/gastos_hoje - Ver gastos de hoje\n"
            "/help - Ajuda\n\n"
            "Você também pode enviar fotos de notas fiscais (em breve)!",
            parse_mode='Markdown'
        )
        logger.info("Mensagem enviada com sucesso!")
    except Exception as e:
        logger.error(f"ERRO ao enviar mensagem: {e}")

# Comando /help
async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🤖 *Como usar o bot:*\n\n"
        "1️⃣ Use /add para registrar um gasto\n"
        "2️⃣ Siga as instruções e informe:\n"
        "   • Valor\n"
        "   • Categoria\n"
        "   • Forma de pagamento\n"
        "   • Descrição (opcional)\n\n"
        "3️⃣ Use /relatorio_semanal ou /relatorio_mensal para ver seus gastos\n\n"
        "💡 *Dica:* Em breve você poderá enviar fotos de notas fiscais!",
        parse_mode='Markdown'
    )

# Iniciar adição de gasto
async def add_expense_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "💰 Vamos registrar um novo gasto!\n\n"
        "Qual o *valor*? (Ex: 50.00 ou 50)",
        parse_mode='Markdown'
    )
    return AMOUNT

# Receber valor
async def receive_amount(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.replace(',', '.')
    
    # Extrair valor numérico
    match = re.search(r'\d+\.?\d*', text)
    if not match:
        await update.message.reply_text(
            "❌ Valor inválido! Por favor, envie apenas números.\n"
            "Exemplo: 50.00 ou 50"
        )
        return AMOUNT
    
    try:
        amount = Decimal(match.group())
        context.user_data['amount'] = amount
        
        # Mostrar categorias
        keyboard = create_keyboard(CATEGORIES, columns=2)
        await update.message.reply_text(
            f"✅ Valor: R$ {amount:.2f}\n\n"
            "📂 Escolha a *categoria*:",
            reply_markup=keyboard,
            parse_mode='Markdown'
        )
        return CATEGORY
    except Exception as e:
        logger.error(f"Erro ao processar valor: {e}")
        await update.message.reply_text("❌ Erro ao processar o valor. Tente novamente.")
        return AMOUNT

# Receber categoria
async def receive_category(update: Update, context: ContextTypes.DEFAULT_TYPE):
    category = update.message.text
    
    if category not in CATEGORIES:
        keyboard = create_keyboard(CATEGORIES, columns=2)
        await update.message.reply_text(
            "❌ Categoria inválida! Por favor, escolha uma das opções:",
            reply_markup=keyboard
        )
        return CATEGORY
    
    context.user_data['category'] = category
    
    # Mostrar métodos de pagamento
    keyboard = create_keyboard(PAYMENT_METHODS, columns=2)
    await update.message.reply_text(
        f"✅ Categoria: {category}\n\n"
        "💳 Escolha a *forma de pagamento*:",
        reply_markup=keyboard,
        parse_mode='Markdown'
    )
    return PAYMENT_METHOD

# Receber método de pagamento
async def receive_payment_method(update: Update, context: ContextTypes.DEFAULT_TYPE):
    payment_method = update.message.text
    
    if payment_method not in PAYMENT_METHODS:
        keyboard = create_keyboard(PAYMENT_METHODS, columns=2)
        await update.message.reply_text(
            "❌ Forma de pagamento inválida! Por favor, escolha uma das opções:",
            reply_markup=keyboard
        )
        return PAYMENT_METHOD
    
    context.user_data['payment_method'] = payment_method
    
    await update.message.reply_text(
        f"✅ Pagamento: {payment_method}\n\n"
        "📝 Adicione uma *descrição* (opcional)\n"
        "Ou envie /pular para finalizar:",
        reply_markup=ReplyKeyboardRemove(),
        parse_mode='Markdown'
    )
    return DESCRIPTION

# Receber descrição
async def receive_description(update: Update, context: ContextTypes.DEFAULT_TYPE):
    description = update.message.text
    context.user_data['description'] = description
    
    return await save_expense(update, context)

# Pular descrição
async def skip_description(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data['description'] = None
    return await save_expense(update, context)

# Salvar gasto no banco
async def save_expense(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    try:
        data = {
            'user_id': user_id,
            'amount': float(context.user_data['amount']),
            'category': context.user_data['category'],
            'payment_method': context.user_data['payment_method'],
            'description': context.user_data.get('description'),
            'date': datetime.now().date().isoformat()
        }
        
        result = supabase.table('expenses').insert(data).execute()
        
        await update.message.reply_text(
            "✅ *Gasto registrado com sucesso!*\n\n"
            f"💰 Valor: R$ {context.user_data['amount']:.2f}\n"
            f"📂 Categoria: {context.user_data['category']}\n"
            f"💳 Pagamento: {context.user_data['payment_method']}\n"
            f"📝 Descrição: {context.user_data.get('description', 'Sem descrição')}\n\n"
            "Use /add para adicionar outro gasto!",
            parse_mode='Markdown'
        )
    except Exception as e:
        logger.error(f"Erro ao salvar gasto: {e}")
        await update.message.reply_text(
            "❌ Erro ao salvar o gasto. Por favor, tente novamente."
        )
    
    context.user_data.clear()
    return ConversationHandler.END

# Cancelar operação
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text(
        "❌ Operação cancelada!",
        reply_markup=ReplyKeyboardRemove()
    )
    return ConversationHandler.END

# Relatório semanal
async def weekly_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    # Data de 7 dias atrás
    start_date = (datetime.now() - timedelta(days=7)).date()
    
    try:
        response = supabase.table('expenses')\
            .select('*')\
            .eq('user_id', user_id)\
            .gte('date', start_date.isoformat())\
            .execute()
        
        expenses = response.data
        
        if not expenses:
            await update.message.reply_text("📊 Nenhum gasto registrado nos últimos 7 dias.")
            return
        
        # Calcular totais
        total = sum(Decimal(str(e['amount'])) for e in expenses)
        
        # Agrupar por categoria
        by_category = {}
        for e in expenses:
            cat = e['category']
            by_category[cat] = by_category.get(cat, Decimal('0')) + Decimal(str(e['amount']))
        
        # Agrupar por forma de pagamento
        by_payment = {}
        for e in expenses:
            pm = e['payment_method']
            by_payment[pm] = by_payment.get(pm, Decimal('0')) + Decimal(str(e['amount']))
        
        # Montar relatório
        report = "📊 *RELATÓRIO SEMANAL*\n"
        report += f"📅 Período: {start_date.strftime('%d/%m/%Y')} até hoje\n\n"
        report += f"💰 *Total Geral: R$ {total:.2f}*\n\n"
        
        report += "📂 *Por Categoria:*\n"
        for cat, amt in sorted(by_category.items(), key=lambda x: x[1], reverse=True):
            percent = (amt / total * 100) if total > 0 else 0
            report += f"  • {cat}: R$ {amt:.2f} ({percent:.1f}%)\n"
        
        report += "\n💳 *Por Forma de Pagamento:*\n"
        for pm, amt in sorted(by_payment.items(), key=lambda x: x[1], reverse=True):
            percent = (amt / total * 100) if total > 0 else 0
            report += f"  • {pm}: R$ {amt:.2f} ({percent:.1f}%)\n"
        
        await update.message.reply_text(report, parse_mode='Markdown')
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório semanal: {e}")
        await update.message.reply_text("❌ Erro ao gerar relatório. Tente novamente.")

# Relatório mensal
async def monthly_report(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    
    # Primeiro dia do mês atual
    today = datetime.now()
    start_date = today.replace(day=1).date()
    
    try:
        response = supabase.table('expenses')\
            .select('*')\
            .eq('user_id', user_id)\
            .gte('date', start_date.isoformat())\
            .execute()
        
        expenses = response.data
        
        if not expenses:
            await update.message.reply_text("📊 Nenhum gasto registrado neste mês.")
            return
        
        # Calcular totais
        total = sum(Decimal(str(e['amount'])) for e in expenses)
        
        # Agrupar por categoria
        by_category = {}
        for e in expenses:
            cat = e['category']
            by_category[cat] = by_category.get(cat, Decimal('0')) + Decimal(str(e['amount']))
        
        # Agrupar por forma de pagamento
        by_payment = {}
        for e in expenses:
            pm = e['payment_method']
            by_payment[pm] = by_payment.get(pm, Decimal('0')) + Decimal(str(e['amount']))
        
        # Montar relatório
        report = "📊 *RELATÓRIO MENSAL*\n"
        report += f"📅 Mês: {today.strftime('%B/%Y')}\n\n"
        report += f"💰 *Total Geral: R$ {total:.2f}*\n\n"
        
        report += "📂 *Por Categoria:*\n"
        for cat, amt in sorted(by_category.items(), key=lambda x: x[1], reverse=True):
            percent = (amt / total * 100) if total > 0 else 0
            report += f"  • {cat}: R$ {amt:.2f} ({percent:.1f}%)\n"
        
        report += "\n💳 *Por Forma de Pagamento:*\n"
        for pm, amt in sorted(by_payment.items(), key=lambda x: x[1], reverse=True):
            percent = (amt / total * 100) if total > 0 else 0
            report += f"  • {pm}: R$ {amt:.2f} ({percent:.1f}%)\n"
        
        await update.message.reply_text(report, parse_mode='Markdown')
        
    except Exception as e:
        logger.error(f"Erro ao gerar relatório mensal: {e}")
        await update.message.reply_text("❌ Erro ao gerar relatório. Tente novamente.")

# Gastos de hoje
async def today_expenses(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    today = datetime.now().date()
    
    try:
        response = supabase.table('expenses')\
            .select('*')\
            .eq('user_id', user_id)\
            .eq('date', today.isoformat())\
            .execute()
        
        expenses = response.data
        
        if not expenses:
            await update.message.reply_text("📊 Nenhum gasto registrado hoje.")
            return
        
        total = sum(Decimal(str(e['amount'])) for e in expenses)
        
        report = f"📊 *GASTOS DE HOJE* ({today.strftime('%d/%m/%Y')})\n\n"
        report += f"💰 *Total: R$ {total:.2f}*\n\n"
        
        for e in expenses:
            desc = e['description'] if e['description'] else 'Sem descrição'
            report += f"• R$ {Decimal(str(e['amount'])):.2f} - {e['category']}\n"
            report += f"  {e['payment_method']} - {desc}\n\n"
        
        await update.message.reply_text(report, parse_mode='Markdown')
        
    except Exception as e:
        logger.error(f"Erro ao buscar gastos de hoje: {e}")
        await update.message.reply_text("❌ Erro ao buscar gastos. Tente novamente.")

# Main
def main():
    application = Application.builder().token(TELEGRAM_TOKEN).build()
    
    # Handlers
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("relatorio_semanal", weekly_report))
    application.add_handler(CommandHandler("relatorio_mensal", monthly_report))
    application.add_handler(CommandHandler("gastos_hoje", today_expenses))
    
    # Conversation handler para adicionar gastos
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("add", add_expense_start)],
        states={
            AMOUNT: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_amount)],
            CATEGORY: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_category)],
            PAYMENT_METHOD: [MessageHandler(filters.TEXT & ~filters.COMMAND, receive_payment_method)],
            DESCRIPTION: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, receive_description),
                CommandHandler("pular", skip_description)
            ],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )
    
    application.add_handler(conv_handler)
    
    # Iniciar bot
    logger.info("Bot iniciado!")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == '__main__':
    main()

